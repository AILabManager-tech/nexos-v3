#!/usr/bin/env python3
"""
generate_tailwind.py — Génère tailwind.config.ts à partir de design-tokens.json

Usage:
    python generate_tailwind.py <tokens_path> <output_dir>

Exemple:
    python generate_tailwind.py clients/USINE_RH/design-tokens.json clients/USINE_RH/
"""

import json
import sys
from pathlib import Path

# ── Échelles typographiques modulaires (ratio) ──────────────────────────
SCALES = {
    "minor-second":   1.067,
    "major-second":   1.125,
    "minor-third":    1.200,
    "major-third":    1.250,
    "perfect-fourth": 1.333,
}

SECTION_GAPS = {
    "compact":  {"py": "3rem",  "gap": "2rem"},
    "normal":   {"py": "5rem",  "gap": "3rem"},
    "spacious": {"py": "8rem",  "gap": "4rem"},
}

SHADOW_PRESETS = {
    "none":     {"sm": "none", "md": "none", "lg": "none"},
    "subtle":   {"sm": "0 1px 3px rgba(0,0,0,0.08)", "md": "0 4px 12px rgba(0,0,0,0.1)", "lg": "0 8px 24px rgba(0,0,0,0.12)"},
    "medium":   {"sm": "0 2px 6px rgba(0,0,0,0.15)", "md": "0 6px 20px rgba(0,0,0,0.2)", "lg": "0 12px 40px rgba(0,0,0,0.25)"},
    "dramatic": {"sm": "0 2px 8px rgba(0,0,0,0.3)",  "md": "0 4px 16px rgba(0,0,0,0.4)", "lg": "0 8px 32px rgba(0,0,0,0.5)"},
}


def load_tokens(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def generate_font_sizes(scale_name: str, base_px: int = 16) -> dict:
    ratio = SCALES.get(scale_name, 1.125)
    sizes = {}
    labels = ["xs", "sm", "base", "lg", "xl", "2xl", "3xl", "4xl", "5xl"]
    # base = index 2
    for i, label in enumerate(labels):
        exp = i - 2
        px = round(base_px * (ratio ** exp), 1)
        rem = round(px / 16, 4)
        lh = round(1.6 - (exp * 0.05), 2) if exp >= 0 else 1.6
        lh = max(1.1, min(1.8, lh))
        sizes[label] = f"['{rem}rem', {{ lineHeight: '{lh}' }}]"
    return sizes


def color_obj_to_ts(colors: dict, indent: int = 8) -> str:
    pad = " " * indent
    lines = []
    for shade, hex_val in sorted(colors.items(), key=lambda x: int(x[0]) if x[0].isdigit() else 0):
        lines.append(f"{pad}{shade}: '{hex_val}',")
    return "\n".join(lines)


def generate_tailwind_config(tokens: dict) -> str:
    t = tokens
    meta = t["meta"]
    colors = t["colors"]
    typo = t["typography"]
    spacing = t["spacing"]
    borders = t["borders"]
    shadows_conf = t.get("shadows", {})
    layout = t["layout"]
    motion = t.get("motion", {})

    # ── Font sizes ───────────────────────────────────────────────────
    base_px = int(typo.get("base_size", "16px").replace("px", ""))
    font_sizes = generate_font_sizes(typo.get("scale", "major-second"), base_px)

    # ── Shadows ──────────────────────────────────────────────────────
    intensity = shadows_conf.get("intensity", "subtle")
    shadow_defaults = SHADOW_PRESETS.get(intensity, SHADOW_PRESETS["subtle"])
    shadows = {
        "sm":  shadows_conf.get("sm",  shadow_defaults["sm"]),
        "md":  shadows_conf.get("md",  shadow_defaults["md"]),
        "lg":  shadows_conf.get("lg",  shadow_defaults["lg"]),
    }

    # ── Section gap ──────────────────────────────────────────────────
    gap = SECTION_GAPS.get(spacing.get("section_gap", "normal"), SECTION_GAPS["normal"])

    # ── Heading font config ──────────────────────────────────────────
    h_font = typo["font_heading"]
    b_font = typo["font_body"]
    m_font = typo.get("font_mono", {})

    # ── Border radius ────────────────────────────────────────────────
    br = borders.get("radius", {})

    config = f"""// ──────────────────────────────────────────────────────────────────────
// NEXOS — Tailwind Config auto-générée depuis design-tokens.json
// Client  : {meta['client_slug']}
// Archétype: {meta['archetype']}
// Mood    : {meta.get('style_mood', 'n/a')}
// ⚠️  NE PAS ÉDITER MANUELLEMENT — regénérer via generate_tailwind.py
// ──────────────────────────────────────────────────────────────────────

import type {{ Config }} from "tailwindcss";

const config: Config = {{
  content: [
    "./src/**/*.{{js,ts,jsx,tsx,mdx}}",
  ],
  theme: {{
    extend: {{
      // ── COULEURS (design-tokens.colors) ─────────────────────────
      colors: {{
        primary: {{
{color_obj_to_ts(colors['primary'])}
        }},
        secondary: {{
{color_obj_to_ts(colors['secondary'])}
        }},
        accent: {{
{color_obj_to_ts(colors['accent'])}
        }},
        neutral: {{
{color_obj_to_ts(colors['neutral'])}
        }},
        background: '{colors['background']}',
        foreground: '{colors['foreground']}',
        surface: '{colors.get('surface', colors['background'])}',
        error: '{colors.get('error', '#dc2626')}',
        success: '{colors.get('success', '#16a34a')}',
        warning: '{colors.get('warning', '#f59e0b')}',
      }},

      // ── TYPOGRAPHIE ─────────────────────────────────────────────
      fontFamily: {{
        heading: ['{h_font['family']}', 'sans-serif'],
        body: ['{b_font['family']}', 'sans-serif'],
        mono: ['{m_font.get('family', 'JetBrains Mono')}', 'monospace'],
      }},
      fontSize: {{
        {chr(10).join(f"        {k}: {v}," for k, v in font_sizes.items())}
      }},

      // ── ESPACEMENT ──────────────────────────────────────────────
      spacing: {{
        'section-y': '{gap['py']}',
        'section-gap': '{gap['gap']}',
      }},
      maxWidth: {{
        'container': '{spacing.get('container_max', '1280px')}',
        'content': '{spacing.get('content_max', '768px')}',
      }},

      // ── BORDURES ────────────────────────────────────────────────
      borderRadius: {{
        none: '{br.get('none', '0px')}',
        sm: '{br.get('sm', '4px')}',
        md: '{br.get('md', '8px')}',
        lg: '{br.get('lg', '16px')}',
        xl: '{br.get('xl', '24px')}',
        full: '{br.get('full', '9999px')}',
      }},
      borderWidth: {{
        DEFAULT: '{borders.get('width', '1px')}',
      }},

      // ── OMBRES ──────────────────────────────────────────────────
      boxShadow: {{
        sm: '{shadows['sm']}',
        md: '{shadows['md']}',
        lg: '{shadows['lg']}',
        none: 'none',
      }},

      // ── ANIMATIONS ──────────────────────────────────────────────
      transitionDuration: {{
        DEFAULT: '{'300ms' if motion.get('intensity', 'subtle') in ['moderate', 'expressive'] else '150ms'}',
      }},
    }},
  }},
  plugins: [],
}};

export default config;
"""
    return config


def generate_css_variables(tokens: dict) -> str:
    """Génère un fichier CSS avec les custom properties pour usage hors-Tailwind."""
    t = tokens
    meta = t["meta"]
    colors = t["colors"]
    typo = t["typography"]
    borders = t["borders"]
    h_font = typo["font_heading"]

    css = f"""/* ──────────────────────────────────────────────────────────────────
   NEXOS — CSS Custom Properties (design-tokens.json)
   Client: {meta['client_slug']}
   ────────────────────────────────────────────────────────────────── */

:root {{
  /* Couleurs sémantiques */
  --color-primary: {colors['primary']['500']};
  --color-secondary: {colors['secondary']['500']};
  --color-accent: {colors['accent']['500']};
  --color-bg: {colors['background']};
  --color-fg: {colors['foreground']};
  --color-surface: {colors.get('surface', colors['background'])};

  /* Typographie */
  --font-heading: '{h_font['family']}', sans-serif;
  --font-body: '{typo['font_body']['family']}', sans-serif;
  --heading-tracking: {h_font.get('letter_spacing', 'normal')};
  --heading-transform: {h_font.get('text_transform', 'none')};
  --body-line-height: {typo['font_body'].get('line_height', 1.6)};

  /* Borders */
  --radius-sm: {borders.get('radius', {}).get('sm', '4px')};
  --radius-md: {borders.get('radius', {}).get('md', '8px')};
  --radius-lg: {borders.get('radius', {}).get('lg', '16px')};
  --border-width: {borders.get('width', '1px')};
}}

/* Headings global style */
h1, h2, h3, h4, h5, h6 {{
  font-family: var(--font-heading);
  letter-spacing: var(--heading-tracking);
  text-transform: var(--heading-transform);
}}
"""
    return css


def generate_google_fonts_import(tokens: dict) -> str:
    """Génère le lien Google Fonts pour next/font ou <link>."""
    typo = tokens["typography"]
    families = []

    for font_key in ["font_heading", "font_body"]:
        font = typo.get(font_key, {})
        name = font.get("family", "")
        weights = font.get("weights", [400])
        if name and name not in ["system-ui", "sans-serif", "serif", "monospace"]:
            weights_str = ";".join(str(w) for w in sorted(weights))
            families.append(f"family={name.replace(' ', '+')}:wght@{weights_str}")

    if not families:
        return ""

    return f"https://fonts.googleapis.com/css2?{'&'.join(families)}&display=swap"


def main():
    if len(sys.argv) < 3:
        print(f"Usage: {sys.argv[0]} <tokens.json> <output_dir>")
        sys.exit(1)

    tokens_path = Path(sys.argv[1])
    output_dir = Path(sys.argv[2])
    output_dir.mkdir(parents=True, exist_ok=True)

    tokens = load_tokens(str(tokens_path))
    slug = tokens["meta"]["client_slug"]

    # 1. tailwind.config.ts
    tw_config = generate_tailwind_config(tokens)
    tw_path = output_dir / "tailwind.config.ts"
    tw_path.write_text(tw_config, encoding="utf-8")
    print(f"[✓] tailwind.config.ts → {tw_path}")

    # 2. CSS custom properties
    css = generate_css_variables(tokens)
    css_path = output_dir / "design-tokens.css"
    css_path.write_text(css, encoding="utf-8")
    print(f"[✓] design-tokens.css  → {css_path}")

    # 3. Google Fonts URL
    gf_url = generate_google_fonts_import(tokens)
    if gf_url:
        gf_path = output_dir / "google-fonts-url.txt"
        gf_path.write_text(gf_url, encoding="utf-8")
        print(f"[✓] google-fonts-url   → {gf_path}")

    # 4. Copie des tokens dans le projet pour référence
    tokens_copy = output_dir / "design-tokens.json"
    tokens_copy.write_text(json.dumps(tokens, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[✓] design-tokens.json → {tokens_copy}")

    print(f"\n── Résumé {slug} ──")
    print(f"   Archétype : {tokens['meta']['archetype']}")
    print(f"   Mood      : {tokens['meta'].get('style_mood', 'n/a')}")
    print(f"   Heading   : {tokens['typography']['font_heading']['family']}")
    print(f"   Body      : {tokens['typography']['font_body']['family']}")
    print(f"   Nav       : {tokens['layout']['nav_style']}")
    print(f"   Hero      : {tokens['layout']['hero_style']}")
    print(f"   Cards     : {tokens['layout']['card_style']}")
    print(f"   Radius sm : {tokens['borders']['radius']['sm']}")
    anti = tokens.get("anti_patterns", [])
    if anti:
        print(f"   Anti-patterns : {', '.join(anti[:3])}")


if __name__ == "__main__":
    main()
