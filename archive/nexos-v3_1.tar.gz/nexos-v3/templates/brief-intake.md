# NEXOS v3.0 — Brief Client

## Informations générales
- **Nom du client** :
- **Nom de l'entreprise** :
- **Secteur d'activité** :
- **URL existante** (si applicable) :
- **URL cible** (domaine souhaité) :

## Objectifs du site
- **Type de site** : [ ] Vitrine [ ] E-commerce [ ] Blog [ ] Portfolio [ ] Autre
- **Objectif principal** :
- **Audience cible** :
- **Zone géographique** : [ ] Québec [ ] Canada [ ] International

## Contenu
- **Pages souhaitées** :
- **Langues** : [ ] Français [ ] Anglais [ ] Autres :
- **Contenu existant à migrer** : [ ] Oui [ ] Non
- **Chatbot IA** : [ ] Oui [ ] Non

## Design
- **Références visuelles** (URLs) :
- **Palette de couleurs** (si existante) :
- **Logo fourni** : [ ] Oui [ ] Non

## Technique
- **Domaine** : [ ] Existant [ ] À acheter
- **Hébergement** : [ ] Vercel (défaut) [ ] Autre
- **Fonctionnalités spéciales** :

## Budget & Délai
- **Budget** :
- **Délai souhaité** :

## Notes libres
