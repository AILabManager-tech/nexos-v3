"""
NEXOS v3.0 Orchestrator — Multi-phase avec quality gates SOIC
"""

import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn
    console = Console()
except ImportError:
    # Fallback si rich n'est pas installé
    class Console:
        def print(self, *a, **kw): print(*a)
    console = Console()

NEXOS_ROOT = Path(__file__).parent.resolve()
CLIENTS_DIR = NEXOS_ROOT / "clients"
AGENTS_DIR = NEXOS_ROOT / "agents"
TOOLS_DIR = NEXOS_ROOT / "tools"
LOGS_DIR = NEXOS_ROOT / "logs"

# ── Quality gate thresholds ──────────────────────────────────────────────────
GATE_THRESHOLDS = {
    "ph0-discovery": 7.0,
    "ph1-strategy":  8.0,
    "ph2-design":    8.0,
    "ph3-content":   8.0,
    "ph4-build":     None,   # BUILD PASS (binaire)
    "ph5-qa":        8.5,
}

# ── Phase sequence ───────────────────────────────────────────────────────────
PHASES_CREATE = [
    "ph0-discovery", "ph1-strategy", "ph2-design",
    "ph3-content", "ph4-build", "ph5-qa"
]

PHASES_MAP = {
    "create":  PHASES_CREATE,
    "audit":   ["ph5-qa"],
    "modify":  ["site-update"],
    "content": ["ph3-content"],
    "analyze": ["ph0-discovery"],
}


def slugify(name: str) -> str:
    """Convertit un nom en slug kebab-case."""
    import re
    slug = name.lower().strip()
    for pattern, repl in [
        (r'[àáâãäå]', 'a'), (r'[èéêë]', 'e'), (r'[ìíîï]', 'i'),
        (r'[òóôõö]', 'o'), (r'[ùúûü]', 'u'), (r'[ç]', 'c'),
    ]:
        slug = re.sub(pattern, repl, slug)
    slug = re.sub(r'[^a-z0-9]+', '-', slug).strip('-')
    return slug


def generate_brief(mode: str, answers: dict, free_text: str = "") -> Path:
    """Génère le brief-client.json et retourne le chemin du dossier client."""
    timestamp = datetime.now().isoformat()
    client_name = answers.get("client_name", f"projet-{datetime.now().strftime('%Y-%m-%d')}")
    slug = slugify(client_name)

    client_dir = CLIENTS_DIR / slug
    client_dir.mkdir(parents=True, exist_ok=True)
    (client_dir / "tooling").mkdir(exist_ok=True)
    (client_dir / "site").mkdir(exist_ok=True)

    brief = {
        "_meta": {
            "generator": "nexos-v3.0",
            "created_at": timestamp,
            "mode": mode,
        },
        "client": {"name": client_name, "slug": slug},
        "mission": {
            "mode": mode,
            "phases": PHASES_MAP[mode],
        },
        "inputs": answers,
        "context_libre": free_text,
    }

    brief_path = client_dir / "brief-client.json"
    brief_path.write_text(json.dumps(brief, ensure_ascii=False, indent=2), encoding="utf-8")

    console.print(f"[green]✓[/] Brief généré : {brief_path}")
    return client_dir


def build_phase_prompt(phase: str, client_dir: Path) -> str:
    """Construit le prompt pour une phase avec contexte cumulatif."""
    parts = []

    # 1. Agent directive
    agent_path = AGENTS_DIR / phase / "_orchestrator.md"
    if phase == "site-update":
        agent_path = AGENTS_DIR / "site-update" / "_pipeline.md"
    parts.append(f"Lis {agent_path} et adopte le rôle décrit.")

    # 2. Brief client
    brief_path = client_dir / "brief-client.json"
    parts.append(f"Le brief client est dans {brief_path}. Lis-le.")

    # 3. Feed des phases précédentes
    phase_reports = {
        "ph0-discovery": [],
        "ph1-strategy":  ["ph0-discovery-report.md"],
        "ph2-design":    ["ph0-discovery-report.md", "ph1-strategy-report.md"],
        "ph3-content":   ["ph0-discovery-report.md", "ph1-strategy-report.md", "ph2-design-report.md"],
        "ph4-build":     ["ph1-strategy-report.md", "ph2-design-report.md", "ph3-content-report.md"],
        "ph5-qa":        ["ph4-build-log.md"],
    }

    for report_name in phase_reports.get(phase, []):
        report_path = client_dir / report_name
        if report_path.exists():
            parts.append(f"Lis {report_path} pour le contexte de la phase précédente.")

    # 4. Tooling data (pour ph5 uniquement)
    if phase == "ph5-qa":
        tooling_dir = client_dir / "tooling"
        if tooling_dir.exists() and any(tooling_dir.iterdir()):
            parts.append(
                f"Les résultats de tooling réel sont dans {tooling_dir}/. "
                f"Lis CHAQUE fichier JSON. Ce sont des MESURES RÉELLES, "
                f"pas des estimations. Base ton audit sur ces données."
            )

    # 5. Output
    output_map = {
        "ph0-discovery": "ph0-discovery-report.md",
        "ph1-strategy":  "ph1-strategy-report.md",
        "ph2-design":    "ph2-design-report.md",
        "ph3-content":   "ph3-content-report.md",
        "ph4-build":     "ph4-build-log.md",
        "ph5-qa":        "ph5-qa-report.md",
    }
    output_file = output_map.get(phase, f"{phase}-report.md")
    parts.append(f"Écris ton rapport dans {client_dir / output_file}")

    return "\n".join(parts)


def run_preflight_tooling(client_dir: Path, url: str) -> bool:
    """Exécute les outils CLI de mesure AVANT les agents LLM."""
    console.print("\n[bold cyan]⚡ TOOLING PREFLIGHT[/]")

    preflight_script = TOOLS_DIR / "preflight.sh"
    if not preflight_script.exists():
        console.print("[yellow]⚠ tools/preflight.sh non trouvé — skip tooling[/]")
        return True

    try:
        result = subprocess.run(
            ["bash", str(preflight_script), url, str(client_dir)],
            cwd=str(NEXOS_ROOT),
            timeout=120,
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            console.print("[green]✓[/] Tooling preflight terminé")
        else:
            console.print(f"[yellow]⚠[/] Tooling preflight partiel (code {result.returncode})")
            if result.stderr:
                console.print(f"[dim]{result.stderr[:500]}[/]")
        return True
    except subprocess.TimeoutExpired:
        console.print("[yellow]⚠ Tooling timeout (120s) — skip[/]")
        return True
    except Exception as e:
        console.print(f"[red]✗ Tooling error: {e}[/]")
        return True  # Non-bloquant


def run_soic_gate(phase: str, client_dir: Path) -> tuple[bool, float]:
    """Exécute le quality gate SOIC pour une phase."""
    from soic.gate import evaluate_gate

    threshold = GATE_THRESHOLDS.get(phase)
    if threshold is None:
        # Phase 4 = BUILD PASS (binaire)
        build_log = client_dir / "ph4-build-log.md"
        if build_log.exists():
            content = build_log.read_text()
            passed = "BUILD PASS" in content or "build réussi" in content.lower()
            return passed, 10.0 if passed else 0.0
        return True, 10.0  # Assume pass si pas de log

    try:
        mu = evaluate_gate(phase, client_dir)
        passed = mu >= threshold
        return passed, mu
    except Exception as e:
        console.print(f"[yellow]⚠ SOIC gate error: {e} — PASS par défaut[/]")
        return True, 0.0


def run_claude_cli(prompt: str, cwd: str, log_path: Path) -> int:
    """Lance claude CLI avec le prompt et capture la sortie."""
    cmd = ["claude", "--dangerously-skip-permissions", "-p", prompt]

    log_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        process = subprocess.Popen(
            cmd, cwd=cwd,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, bufsize=1,
        )

        with open(log_path, "w", encoding="utf-8") as log:
            log.write(f"# NEXOS v3.0 Log\n")
            log.write(f"# Date: {datetime.now().isoformat()}\n")
            log.write(f"# Prompt:\n{prompt}\n\n---\n\n")

            for line in process.stdout:
                sys.stdout.write(line)
                sys.stdout.flush()
                log.write(line)

        process.wait()
        return process.returncode

    except FileNotFoundError:
        console.print(
            "[red bold]Claude CLI non trouvé.[/]\n"
            "Installe-le avec: [cyan]npm install -g @anthropic-ai/claude-code[/]"
        )
        return 1
    except KeyboardInterrupt:
        console.print("\n[yellow]⚠ Interrompu par l'utilisateur[/]")
        if process:
            process.terminate()
        return 130


def run_pipeline(mode: str, client_dir: Path, url: Optional[str] = None):
    """Exécute le pipeline complet pour un mode donné."""
    phases = PHASES_MAP[mode]
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M")

    gate_history = []

    console.print(Panel(
        f"[bold]Mode:[/] {mode}\n"
        f"[bold]Client:[/] {client_dir.name}\n"
        f"[bold]Phases:[/] {' → '.join(phases)}",
        title="[bold cyan]⚡ NEXOS v3.0[/]",
        border_style="cyan",
    ))

    for i, phase in enumerate(phases):
        console.print(f"\n[bold]{'━'*60}[/]")
        console.print(f"[bold cyan]PHASE {i}: {phase.upper()}[/]")
        console.print(f"[bold]{'━'*60}[/]\n")

        # Tooling preflight avant ph5
        if phase == "ph5-qa" and url:
            run_preflight_tooling(client_dir, url)

        # Construire le prompt
        prompt = build_phase_prompt(phase, client_dir)
        log_path = LOGS_DIR / f"{timestamp}_{phase}.log"

        # Exécuter Claude CLI
        returncode = run_claude_cli(prompt, str(NEXOS_ROOT), log_path)

        if returncode != 0:
            console.print(f"[red]✗ Phase {phase} échouée (code {returncode})[/]")
            break

        # Quality gate (sauf dernière phase en mode create)
        if phase in GATE_THRESHOLDS and phase != phases[-1]:
            passed, mu = run_soic_gate(phase, client_dir)
            gate_history.append({
                "phase": phase,
                "mu": mu,
                "threshold": GATE_THRESHOLDS[phase],
                "passed": passed,
                "timestamp": datetime.now().isoformat(),
            })

            if passed:
                console.print(f"[green]✓ SOIC GATE: μ={mu:.1f} ≥ {GATE_THRESHOLDS[phase]} — PASS[/]")
            else:
                console.print(f"[red]✗ SOIC GATE: μ={mu:.1f} < {GATE_THRESHOLDS[phase]} — FAIL[/]")
                console.print("[yellow]→ Re-run de la phase nécessaire[/]")
                break

    # Sauvegarder l'historique des gates
    gates_path = client_dir / "soic-gates.json"
    gates_path.write_text(json.dumps(gate_history, indent=2), encoding="utf-8")

    console.print(Panel(
        f"[green]Pipeline terminé[/]\n"
        f"[dim]Client: {client_dir}[/]\n"
        f"[dim]Gates: {len(gate_history)} évaluées[/]",
        title="[bold green]✓ NEXOS v3.0 TERMINÉ[/]",
        border_style="green",
    ))


# ── Entry point ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="NEXOS v3.0 Orchestrator")
    parser.add_argument("mode", choices=["create", "audit", "modify", "content", "analyze"])
    parser.add_argument("--client-dir", type=Path, help="Dossier client existant")
    parser.add_argument("--url", type=str, help="URL du site (pour audit/preflight)")
    parser.add_argument("--brief", type=str, help="Chemin vers brief-client.json")

    args = parser.parse_args()

    if args.client_dir:
        client_dir = args.client_dir
    elif args.brief:
        brief_data = json.loads(Path(args.brief).read_text())
        client_dir = generate_brief(args.mode, brief_data.get("inputs", {}))
    else:
        console.print("[red]Erreur: --client-dir ou --brief requis[/]")
        sys.exit(1)

    run_pipeline(args.mode, client_dir, url=args.url)
