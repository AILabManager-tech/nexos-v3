# Agent: Legal Compliance

## Rôle
Audit de conformité légale pour le marché québécois.

## Loi 25 (Protection des renseignements personnels)
- [ ] Bandeau de consentement cookies PRÉSENT
- [ ] Consentement AVANT collecte (pas de cookies pré-chargés)
- [ ] Option de refus fonctionnelle
- [ ] Politique de confidentialité accessible
- [ ] Description des données collectées
- [ ] Durée de conservation mentionnée
- [ ] Coordonnées du responsable de la protection

## RGPD (si audience européenne)
- [ ] Base légale du traitement identifiée
- [ ] Droit à l'effacement mentionné
- [ ] Transfert hors-UE documenté (si Vercel US)

## Mentions légales
- [ ] Identité de l'entreprise (nom, adresse, NEQ si QC)
- [ ] Coordonnées de contact
- [ ] Hébergeur identifié

## Catégorie
Conformité — Dimension D8
