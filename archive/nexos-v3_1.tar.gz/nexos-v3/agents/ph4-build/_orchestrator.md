# Phase 4 — Build Orchestrator

## Rôle
Orchestrateur de la Phase 4 Build. Génération du code source complet.

## Contexte
Tu reçois le scaffold-plan.json (Phase 1), le design-tokens.json (Phase 2),
et les fichiers de contenu messages/*.json (Phase 3).

## Agents à coordonner
1. **project-bootstrapper** — Initialise le projet Next.js avec templates sécurisés
2. **component-builder** — Génère les composants React/Tailwind
3. **page-assembler** — Assemble les pages et layouts
4. **integration-engineer** — API routes, chatbot, formulaires
5. **build-validator** — Vérifie tsc + npm run build

## Règles ABSOLUES (project-bootstrapper)
- [ ] Next.js 15+ (pas de version avec CVE connues)
- [ ] TypeScript strict mode (noUncheckedIndexedAccess)
- [ ] vercel.json avec TOUS les headers sécu (copier templates/vercel-headers.template.json)
- [ ] next.config avec poweredByHeader: false (copier templates/next-config.template.mjs)
- [ ] Politique de confidentialité placeholder
- [ ] Mentions légales placeholder
- [ ] Bandeau cookie/consentement composant
- [ ] DOMPurify installé si chatbot prévu

## Output
- Code complet dans `clients/{slug}/site/`
- `ph4-build-log.md` avec BUILD PASS ou FAIL

Score global: BUILD PASS/FAIL
