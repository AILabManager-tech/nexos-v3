#!/bin/bash
# Scan accessibilité WCAG via pa11y
URL="${1:?Usage: a11y-scan.sh <URL>}"

if command -v pa11y &>/dev/null; then
    pa11y "$URL" --reporter json --standard WCAG2AA 2>/dev/null
else
    echo '[]'
    echo "⚠ pa11y non installé: npm i -g pa11y" >&2
fi
