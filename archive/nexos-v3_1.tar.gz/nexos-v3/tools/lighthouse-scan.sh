#!/bin/bash
# Scan Lighthouse complet
URL="${1:?Usage: lighthouse-scan.sh <URL>}"
OUTPUT="${2:-/dev/stdout}"

lighthouse "$URL" \
    --output json \
    --output-path "$OUTPUT" \
    --chrome-flags="--headless --no-sandbox --disable-gpu" \
    --quiet 2>/dev/null
