"""
SOIC v3.0 — Quality Gate
Vérifie si une phase passe le seuil requis.
"""

import json
from pathlib import Path
from .evaluate import evaluate_all
from .dimensions import calculate_mu


def evaluate_gate(phase: str, client_dir: Path) -> float:
    """Évalue le quality gate pour une phase donnée."""
    tooling_dir = client_dir / "tooling"

    if tooling_dir.exists() and any(tooling_dir.iterdir()):
        scores, mu = evaluate_all(tooling_dir)
        return mu

    # Si pas de tooling, parse le rapport de phase pour un score estimé
    report_map = {
        "ph0-discovery": "ph0-discovery-report.md",
        "ph1-strategy":  "ph1-strategy-report.md",
        "ph2-design":    "ph2-design-report.md",
        "ph3-content":   "ph3-content-report.md",
        "ph5-qa":        "ph5-qa-report.md",
    }

    report_path = client_dir / report_map.get(phase, f"{phase}-report.md")
    if report_path.exists():
        # Score par défaut basé sur l'existence du rapport
        # Les agents sont censés écrire un score dans leur rapport
        content = report_path.read_text()
        # Chercher un pattern "Score global: X/10" ou "μ = X"
        import re
        match = re.search(r'(?:score global|μ)\s*[:=]\s*(\d+\.?\d*)', content, re.IGNORECASE)
        if match:
            return float(match.group(1))

    return 7.5  # Score par défaut si rien n'est disponible
