"""
SOIC v3.0 — Évaluation objective (tool-verified)
Calcule les scores D1-D9 à partir des résultats de tooling réel.
"""

import json
from pathlib import Path
from .dimensions import calculate_mu


def evaluate_from_tooling(tooling_dir: Path) -> dict[str, float]:
    """Calcule les scores à partir des mesures réelles des outils CLI."""
    scores = {}

    # ── D5 Performance — Lighthouse réel ──
    lh_path = tooling_dir / "lighthouse.json"
    if lh_path.exists():
        try:
            lh = json.loads(lh_path.read_text())
            perf = lh.get("categories", {}).get("performance", {}).get("score", 0)
            scores["D5"] = perf * 10
        except (json.JSONDecodeError, KeyError):
            scores["D5"] = 5.0
    else:
        scores["D5"] = 5.0  # Score neutre si pas de données

    # ── D6 Accessibilité — pa11y réel ──
    pa11y_path = tooling_dir / "pa11y.json"
    if pa11y_path.exists():
        try:
            pa11y = json.loads(pa11y_path.read_text())
            if isinstance(pa11y, list):
                errors = len([i for i in pa11y if i.get("type") == "error"])
            else:
                errors = pa11y.get("total", 0)
            scores["D6"] = max(0.0, 10.0 - errors * 0.5)
        except (json.JSONDecodeError, KeyError):
            scores["D6"] = 5.0
    else:
        scores["D6"] = 5.0

    # ── D4 Sécurité — Headers HTTP réels ──
    headers_path = tooling_dir / "headers.json"
    if headers_path.exists():
        try:
            headers = json.loads(headers_path.read_text())
            header_names = {k.lower() for k in headers.keys()}
            required = [
                "x-content-type-options", "x-frame-options",
                "referrer-policy", "permissions-policy",
                "strict-transport-security", "content-security-policy",
            ]
            present = sum(1 for h in required if h in header_names)
            score_headers = (present / len(required)) * 10
        except (json.JSONDecodeError, KeyError):
            score_headers = 5.0
    else:
        score_headers = 5.0

    # ── D4 Sécurité — npm audit réel ──
    audit_path = tooling_dir / "npm-audit.json"
    if audit_path.exists():
        try:
            audit = json.loads(audit_path.read_text())
            vulns = audit.get("metadata", {}).get("vulnerabilities", {})
            high = vulns.get("high", 0) + vulns.get("critical", 0)
            score_deps = max(0.0, 10.0 - high * 2)
        except (json.JSONDecodeError, KeyError):
            score_deps = 5.0
    else:
        score_deps = 5.0

    scores["D4"] = (score_headers + score_deps) / 2

    # ── D7 SEO — Lighthouse SEO ──
    if lh_path.exists():
        try:
            lh = json.loads(lh_path.read_text())
            seo = lh.get("categories", {}).get("seo", {}).get("score", 0)
            scores["D7"] = seo * 10
        except (json.JSONDecodeError, KeyError):
            scores["D7"] = 5.0
    else:
        scores["D7"] = 5.0

    # ── D6 Accessibilité — Lighthouse a11y (complément pa11y) ──
    if lh_path.exists():
        try:
            lh = json.loads(lh_path.read_text())
            a11y_lh = lh.get("categories", {}).get("accessibility", {}).get("score", 0)
            # Moyenne pa11y + lighthouse a11y
            scores["D6"] = (scores["D6"] + a11y_lh * 10) / 2
        except (json.JSONDecodeError, KeyError):
            pass

    # ── Dimensions sans tooling (évaluées par les agents LLM) ──
    # Ces scores sont mis à jour par le rapport ph5-qa
    for dim in ["D1", "D2", "D3", "D8", "D9"]:
        if dim not in scores:
            scores[dim] = 5.0  # Neutre par défaut

    return scores


def evaluate_all(tooling_dir: Path) -> tuple[dict[str, float], float]:
    """Évalue toutes les dimensions et calcule μ."""
    scores = evaluate_from_tooling(tooling_dir)
    mu = calculate_mu(scores)
    return scores, mu
