"""
SOIC v3.0 — Génération de rapports
"""

import json
from datetime import datetime
from pathlib import Path
from .dimensions import DIMENSIONS, calculate_mu


def generate_report(scores: dict[str, float], client_dir: Path) -> str:
    """Génère un rapport SOIC au format Markdown."""
    mu = calculate_mu(scores)

    lines = [
        "# Rapport SOIC v3.0",
        f"\n**Date** : {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        f"**Client** : {client_dir.name}",
        f"**μ global** : {mu:.2f}/10.0",
        "",
        "## Scores par dimension",
        "",
        "| Dimension | Score | Poids | Description |",
        "|-----------|-------|-------|-------------|",
    ]

    for dim_id, dim_info in DIMENSIONS.items():
        score = scores.get(dim_id, 0.0)
        status = "✓" if score >= 8.0 else "⚠" if score >= 6.0 else "✗"
        lines.append(
            f"| {status} {dim_id} {dim_info['name']} | {score:.1f}/10 "
            f"| ×{dim_info['weight']} | {dim_info['description']} |"
        )

    lines.extend([
        "",
        f"## Verdict : {'PASS' if mu >= 8.5 else 'FAIL'}",
        f"μ = {mu:.2f} {'≥' if mu >= 8.5 else '<'} 8.5",
    ])

    return "\n".join(lines)
